#!/bin/bash
java -jar --module-path ./openjfx-12.0.1_linux-x64_bin-sdk/lib --add-modules=javafx.controls,javafx.base,javafx.graphics client.jar
