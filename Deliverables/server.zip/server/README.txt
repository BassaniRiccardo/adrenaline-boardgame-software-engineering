Software Engineering Project 2019 - AM43 (Bassani, Bagatella, Aldè)
			Implementation of Adrenaline - SERVER
-------------------------------------------------------------------

INFO:
This jar archive contains the server application.
Properties can be set in server.properties, or default ones will be loaded from inside the jar. 

HOW TO RUN:
After you have configured the .properties file (at least myIP), just double click the jar file (if jre is properly setup). You can also use the bash script included or open a terminal and input "java -jar server.jar" if you prefer.
