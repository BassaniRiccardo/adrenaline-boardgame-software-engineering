Software Engineering Project 2019 - AM43 (Bassani, Bagatella, Aldè)
			Implementation of Adrenaline - CLIENT
-------------------------------------------------------------------

INFO:
This jar archive contains the client application. JavaFx dependencies have been excluded and must be added at launch. Properties can be set in client.properties, or default ones will be loaded from inside the jar. Properties are described inside the file.

HOW TO RUN:
First of all set the IP of your machine (myIP) and that of the server (serverIP) in the .properties file. Then, you can run the bash script included or open a terminal and type:

	java -jar --module-path ./openjfx-12.0.1_linux-x64_bin-sdk/lib --add-modules=javafx.controls,javafx.base,javafx.graphics client.jar

The client can also be launched with parameters:

	java -jar --module-path ./openjfx-12.0.1_linux-x64_bin-sdk/lib --add-modules=javafx.controls,javafx.base,javafx.graphics client.jar [serverIP] [serverPort] [clientIP]

Note: We assume that javafx sdk is in the same folder as the jar file.
