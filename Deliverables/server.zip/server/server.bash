#!/bin/bash
java -jar server.jar
